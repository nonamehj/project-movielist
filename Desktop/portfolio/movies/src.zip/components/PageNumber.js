import { useGlobalContext } from "../context";
import "./PageNumberStyle.css";
const PageNumber = () => {
  const { setIndex } = useGlobalContext();

  const Pages = Array.from({ length: 10 }, (_, index) => {
    return index;
  });
  const prevChange = () => {
    setIndex((oldPage) => {
      let prevPage = oldPage - 1;
      if (prevPage <= 1) prevPage = 1;
      return prevPage;
    });
  };
  const nextChange = () => {
    setIndex((oldPage) => {
      let nextPage = oldPage + 1;
      if (nextPage > Pages.length) {
        nextPage = Pages.length;
      }
      return nextPage;
    });
  };
  const handlePage = (page) => {
    setIndex(page + 1);
  };
  return (
    <div className="page-container">
      <div className="page-btn">
        <button className="prev-btn" onClick={prevChange}>
          prev
        </button>
        <div className="newPage-btn">
          {Pages.map((index) => {
            return (
              <button
                key={index}
                onClick={() => handlePage(index)}
                className="newPage"
              >
                {index + 1}
              </button>
            );
          })}
        </div>
        <button className="next-btn" onClick={nextChange}>
          next
        </button>
      </div>
    </div>
  );
};

export default PageNumber;
