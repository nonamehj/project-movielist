import { useGlobalContext } from "./../context";
import { Link } from "react-router-dom";
import { useState } from "react";
import logo from "../movielogo.webp";
import { FaBars, FaTimes } from "react-icons/fa";
import "./NavbarStyle.css";
const menus = ["Home", "Popular", "Theatre", "Kids", "Comedie"];

const Navbar = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { setIndex, setUrl } = useGlobalContext();

  const getPage = (page) => {
    let url = "";
    setIndex(1);
    setIsSidebarOpen(false);
    if (page === "Home") {
      url = "/discover/movie?sort_by=popularity.desc&page=";
    }
    if (page === "Popular") {
      url = "/discover/movie?sort_by=popularity.desc&page=";
    }

    if (page === "Theatre") {
      url =
        "/discover/movie?primary_release_date.gte=2014-09-15&primary_release_date.lte=2023-11-10&page=";
    }
    if (page === "Kids") {
      url =
        "/discover/movie?certification_country=US&certification.lte=G&sort_by=popularity.desc&page=";
    }
    if (page === "Comedie") {
      url =
        "/discover/movie?with_genres=35&cast_with=23659&sor_by=revenue.esc&page=";
    }

    return setUrl(url);
  };

  return (
    <nav className="navbar">
      <div className="nav-center">
        <Link to="/">
          <img src={logo} alt="logo-img" className="logo" />
        </Link>
        <ul className={isSidebarOpen ? "nav-links active-links" : "nav-links"}>
          {menus.map((menu, index) => {
            return (
              <li key={index}>
                {menu === "Home" ? (
                  <Link to="/" onClick={() => getPage(menu)}>
                    {menu}
                  </Link>
                ) : (
                  <Link to={menu} onClick={() => getPage(menu)}>
                    {menu}
                  </Link>
                )}
              </li>
            );
          })}
        </ul>
        <div
          className="sidebar-menu"
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        >
          {isSidebarOpen ? (
            <button className="close-btn">
              <FaTimes />
            </button>
          ) : (
            <button className="open-btn">
              <FaBars />
            </button>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
