import SharedLayoutPopular from "./SharedLayoutPopular";
import SharedLayoutComedie from "./SharedLayoutComedie";
import SharedLayoutTheatre from "./SharedLayoutTheatre";
import SharedLayoutKids from "./SharedLayoutKids";
import SharedLayoutSearch from "./SharedLayoutSearch";

export {
  SharedLayoutPopular,
  SharedLayoutTheatre,
  SharedLayoutComedie,
  SharedLayoutKids,
  SharedLayoutSearch,
};
