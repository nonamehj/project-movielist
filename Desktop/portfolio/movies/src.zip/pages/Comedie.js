import MoviesList from "../components/MoviesList";

const Comedie = () => {
  return (
    <div>
      <MoviesList name="comedie" />
    </div>
  );
};

export default Comedie;
