import MoviesList from "../components/MoviesList";

const Kids = () => {
  return (
    <div>
      <MoviesList name="kids" />
    </div>
  );
};

export default Kids;
