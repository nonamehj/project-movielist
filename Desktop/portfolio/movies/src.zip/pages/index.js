import Home from "./Home";
import Kids from "./Kids";
import Popular from "./Popular";
import Comedie from "./Comedie";
import Theatre from "./Theatre";
import Search from "./Search";
export { Home, Kids, Popular, Comedie, Theatre, Search };
