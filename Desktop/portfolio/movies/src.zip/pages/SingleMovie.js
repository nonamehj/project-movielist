import "./SingleMovieStyle.css";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useState, useEffect, useCallback } from "react";

const API_KEY = process.env.REACT_APP_API_KEY;
const base_url = "https://api.themoviedb.org/3";
const img_path = "https://image.tmdb.org/t/p/w500";
const SingleMovie = () => {
  const { id } = useParams();
  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  // console.log("movie", movie);
  const fetchSingleMovie = useCallback(async () => {
    setLoading(true);
    const response = await fetch(
      `${base_url}/movie/${id}?language=en-US&api_key=${API_KEY}`
    );
    const data = await response.json();
    // console.log("data", data);
    if (data) {
      const {
        poster_path: img,
        title,
        release_date: date,
        vote_average: average,
        overview,
        runtime,
        popularity,
      } = data;
      const newMovie = {
        img,
        title,
        date,
        average,
        overview,
        runtime,
        popularity,
      };
      setMovie(newMovie);
    } else {
      setMovie(null);
    }
    setLoading(false);
  }, [id]);
  useEffect(() => {
    fetchSingleMovie();
  }, [id, fetchSingleMovie]);
  if (loading) {
    return (
      <section className="section section-loading">
        <div className="loading"></div>
        <h2>loading</h2>
      </section>
    );
  }
  if (!movie) {
    <section className="section no-display">
      <h3>no movie to display</h3>
    </section>;
  } else {
    const { img, title, date, average, overview, runtime, popularity } = movie;
    return (
      <section className="section single-movie-section">
        {/* <div className="single-title"> */}
        {/* </div> */}

        <h2 className="single-title">{title}</h2>
        <div className="single-movie">
          <div className="single-center">
            <img src={`${img_path}${img}`} alt="img" className="single-img" />
          </div>
          <div className="movie-info">
            <p>
              <span className="movie-data">date : {date}</span>
            </p>
            <p>
              <span className="movie-data">title : {title}</span>
            </p>
            <p>
              <span className="movie-data">average : {average.toFixed(2)}</span>
            </p>
            <p>
              <span className="movie-data">runtime : {runtime}h</span>
            </p>
            <p>
              <span className="movie-data">
                popularity : {Math.floor(popularity)}
              </span>
            </p>
            <p>
              <span className="movie-data overview">overview : {overview}</span>
            </p>
          </div>
        </div>
        <Link onClick={() => navigate(-1)} className="btn single-btn">
          back
        </Link>
      </section>
    );
  }
};

export default SingleMovie;
