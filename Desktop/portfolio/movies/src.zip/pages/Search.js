import MoviesList from "../components/MoviesList";

const Search = () => {
  return (
    <div>
      <MoviesList name="search" />
    </div>
  );
};

export default Search;
