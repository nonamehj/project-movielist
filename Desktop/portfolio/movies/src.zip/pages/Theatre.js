import MoviesList from "../components/MoviesList";

const Theatre = () => {
  return (
    <div>
      <MoviesList name="theatre" />
    </div>
  );
};

export default Theatre;
