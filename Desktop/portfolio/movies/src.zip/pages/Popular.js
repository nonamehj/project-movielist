import React from "react";
import MoviesList from "../components/MoviesList";

const Popular = () => {
  return (
    <div>
      <MoviesList name="popular" />
    </div>
  );
};

export default Popular;
