import MainHome from "../components/MainHome";

const Home = () => {
  return (
    <>
      <MainHome />
    </>
  );
};

export default Home;
